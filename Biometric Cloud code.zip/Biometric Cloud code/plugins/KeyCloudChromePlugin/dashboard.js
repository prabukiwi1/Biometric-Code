window.open("https://keycloud-dev.zeekay.dev/dashboard/", '_blank');
