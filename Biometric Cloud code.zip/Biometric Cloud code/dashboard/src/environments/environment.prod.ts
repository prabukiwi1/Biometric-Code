export const environment = {
  production: true,
  apiUrl: `${location.hostname}`,
};
