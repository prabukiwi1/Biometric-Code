export class PasswordEntry {
  constructor(
    public id,
    public username,
    public password,
    public url,
    public del,
  ) {
  }
}
