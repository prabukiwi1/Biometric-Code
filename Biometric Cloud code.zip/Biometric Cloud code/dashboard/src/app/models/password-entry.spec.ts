import { PasswordEntry } from './password-entry';

describe('PasswordEntry', () => {
  it('should create an instance', () => {
    expect(new PasswordEntry('', ' ', ' ', '', '')).toBeTruthy();
  });
});
