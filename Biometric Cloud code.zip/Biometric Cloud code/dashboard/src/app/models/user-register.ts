export class UserRegister {
  constructor(
    public username,
    public mail,
  ) {
  }
}
