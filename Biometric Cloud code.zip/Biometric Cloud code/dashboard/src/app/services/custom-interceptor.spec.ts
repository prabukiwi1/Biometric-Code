import { CustomInterceptor } from './custom-interceptor';

describe('CustomInterceptor', () => {
  it('should create an instance', () => {
    expect(new CustomInterceptor()).toBeTruthy();
  });
});
